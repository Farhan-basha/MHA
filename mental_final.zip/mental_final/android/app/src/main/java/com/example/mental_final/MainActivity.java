package com.example.mental_final;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
